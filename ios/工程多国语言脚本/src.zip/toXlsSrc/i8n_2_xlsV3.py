# !/usr/bin/python
#coding:utf-8

#code by cs

# version 3.0
# 增加增量显示
# 1）获取所有需要扣取的key（一般关键key在第0位）
# 2）遍历所有key，如果是关键key记录关键key中的每个变量字段到字典cache中，字段对应行号，写入xls中
# 3）除了关键key，其他key从cache取出对应的字段所要写入的行号，把文字写入该行


import xlwt
import os
import functools

# from csPrint import csPrint


# 要生成的语言模板
g_key = 'en'
# 要忽略的语言
g_IgnoreKeys = []
# 语言文件路径
g_sourceFile = '/.../Desktop/myself_i8n/Language(国际化)'

# 生成的文件名
g_destXlsFile = ''

import sys, imp, marshal
def load_compiled_from_memory(name, filename, data, ispackage=False):
    if data[:4]!=imp.get_magic():
        raise ImportError('Bad magic number in %s' % filename)
    # Ignore timestamp in data[4:8]
    code = marshal.loads(data[8:])
    imp.acquire_lock() # Required in threaded applications
    try:
        mod = imp.new_module(name)
        sys.modules[name] = mod # To handle circular and submodule imports 
                                # it should come before exec.
        try:
            mod.__file__ = filename # Is not so important.
            # For package you have to set mod.__path__ here. 
            # Here I handle simple cases only.
            if ispackage:
                mod.__path__ = [name.replace('.', '/')]
            exec code in mod.__dict__
        except:
            del sys.modules[name]
            raise
    finally:
        imp.release_lock()
    return mod

csPrint = None
def backPrint(msg, types = ''):
    print msg
try:
    pycData = open('csPrint.cs', 'rb').read()
    tPrint = load_compiled_from_memory('csPrint', 'csPrint', pycData)
    csPrint = tPrint.csPrint
except Exception, e:
    print e
    csPrint = backPrint




class TranslateSourceFile2XLS(object):
    def __init__(self):
        # 是否需要忽略注释
        self.m_flagIgnoreNote = False
        self.m_sourceFile = ''
        self.m_destXlsFile = ''
        self.m_IgnoreKeys = []
        # 如果没有设置key就以keyNum的值做key
        self.m_Keys = ''
        self.m_KeyNum = 0
        self.cacheDict = {}
        self.ws = None
        self.m_col = 1
        
    def listDir(self, path):
    	filelist=[]
        for i in os.listdir(path):
            if i[0] == '.' or os.path.isfile(path + '/' + i):
			    # consolePrint('忽略：' + i)
                csPrint('忽略:' + i, 'action')
                continue
            filelist.append(path + '/' + i)
        return filelist
    def listFiles(self, path):
        filelist=[]
        for i in os.listdir(path):
            if i[0] == '.' or os.path.isdir(path + '/' + i):
			    # consolePrint('忽略：' + i)
                csPrint('忽略文件:' + i, 'action')
                continue
            filelist.append(path + '/' + i)
        return filelist
    def listBaseName(self, paths):
        assert(isinstance(paths, list))
        result = []
        try:
            result = [os.path.basename(x).split('.')[0] for x in paths]
        except Exception, e:
            print e
        return result
    def fileCheck(self, filePath = []):
        result = True
        for xFile in filePath:
            if os.path.exists(xFile) == False:
                result = False
                break
        return result
    def _getRealKey(self):
        # 找到所有的key
        retDirs = self.listDir(self.m_sourceFile)
        retBaseNames = self.listBaseName(retDirs)
        # 是否存在关键key，是否忽略一些key
        real_keys = []
        if self.m_Keys not in retBaseNames:
            csPrint('关键key不匹配', 'error')
            return real_keys
        # real_keys.append('key')
        real_keys.append(self.m_Keys)
        for xkey in retBaseNames:
            if xkey not in self.m_IgnoreKeys and xkey != self.m_Keys:
                real_keys.append(xkey)
        return real_keys
    
    def _fileRead(self, file_path):
        i8nLines = None
        try:
            fh = open(file_path)
            i8nLines = fh.readlines()
            fh.close()
        except Exception, e:
            csPrint("文件读取出错", 'error')
        return i8nLines
        
    def _readAllLines(self, path):
        retFiles = self.listFiles(path)
        retLineDatas = []
        try:
            for itemFile in retFiles:
                retLineDatas.extend(self._fileRead(itemFile))
        except Exception,e:
            csPrint("数据读取出错了", 'error')
        
        return retLineDatas

    def _xlsWrite(self, keyName, sheet_name = 'Sheet cs', list_value = []):
        if len(list_value) == 0:
            csPrint("数据不存在", 'error')
            return -1

        style0 = xlwt.easyxf('font:height 280, name SimSun')
        style1 = xlwt.easyxf('font:height 280, name SimSun, colour_index red, bold on;pattern:pattern solid,fore_colour yellow')
        style2 = xlwt.easyxf('font:height 280, name SimSun, colour_index red, bold on;pattern:pattern solid,fore_colour light_blue')
        ws = self.ws

        # 写入头 and 注释
        
        
        first_row = ws.row(0)
        sec_row = ws.row(1)
        first_row.set_style(style1)
        sec_row.set_style(style2)


        # 记录key所代表语言的每个字符文本的位置
        note2Cache = False
        if keyName == self.m_Keys:
            note2Cache = True

        # 0行 ‘key’字段 1行 ‘关键key字段’
        if note2Cache:
            ws.write(0, 0, 'key', style1)
            ws.write(1, 0, '//注释', style2)
        else:
            self.m_col += 1
        # 写的第一行title
        ws.write(0, self.m_col, keyName, style1)
        ws.write(1, self.m_col, '//注释', style2)


        # 写的具体数据
        index = 2
        noteFlag = False
        for line in list_value:
            if line.strip()[0:2] == '//':
                if self.m_flagIgnoreNote == False:
                    note_row = ws.row(index)
                    note_row.set_style(style2)
                    if note2Cache:
                        ws.write(index, 0, line, style2)
                    ws.write(index, self.m_col, line, style2)
                    index += 1
            elif line.strip()[0:2] == '/*':
                noteFlag = True
            elif line.rstrip('\n')[-2:] == '*/':
                noteFlag = False
            elif noteFlag:
                pass
            else:
                tmpList = line.split('=')
                if len(tmpList) >= 2:
                    value1 = tmpList[0].strip()
                    value1 = value1.strip('"')
                    value2 = tmpList[1].replace(';', '').strip()
                    value2 = value2.strip('"')
                    if note2Cache:
                        self.cacheDict[value1] = index
                        ws.write(index, 0, value1, style0)
                        ws.write(index, 1, value2, style0)
                        index += 1
                    else:
                        tmpIndex = self.cacheDict.get(value1, -1)
                        if tmpIndex != -1:
                            ws.write(tmpIndex, self.m_col, value2, style0)
                        else:
                            csPrint('新增Key:' + keyName + '>' + value1)
                        index += 1

        
    def runTranslate(self, params = {}):
        # 获取将要写入的keys（经过处理后的，关键key在0位）
        willWirteKeys = self._getRealKey()
        if len(willWirteKeys) == 0:
            csPrint('key处理出错了', 'error')
            return
        # 打开xls文件，打开关键文件
        
        wb = xlwt.Workbook(encoding = 'utf-8')
        self.ws = wb.add_sheet('Sheet cs')
        # 遍历所有的key
        for itemKey in willWirteKeys:
            csPrint('开始处理>' + itemKey)
            dataLines = self._readAllLines(self.m_sourceFile + '/' + itemKey + '.lproj/')
            if len(dataLines) > 0:
                self._xlsWrite(keyName = itemKey, list_value = dataLines)
            else:
                csPrint(itemKey + ': 中没有找到任何数据')
        wb.save(self.m_destXlsFile or 'output.xls')
        csPrint("数据转换成功")
            
        

def main():
    ts = TranslateSourceFile2XLS()
    ts.m_Keys = g_Params['key']
    ts.m_IgnoreKeys = g_Params['ignorekeys']
    ts.m_sourceFile = g_sourceFile
    ts.m_destXlsFile = g_Params['output']
    csPrint("主键:" + ts.m_Keys)
    csPrint("忽略:[" + ','.join(ts.m_IgnoreKeys) + "]")
    csPrint("源目录:" + ts.m_sourceFile)
    tmpV = ts.m_destXlsFile or '默认文件'
    csPrint("输出文件:" + tmpV)
    ts.runTranslate()

g_Params = {
    "key":g_key,
    "ignorekeys":g_IgnoreKeys,
    "output":g_destXlsFile
}
if __name__ == '__main__':
    import sys
    if len(sys.argv) != 3:
        csPrint('例子: i8n_2_xls.cs "源路径" "{\"key\":\"en\", \"ignoreKeys\":[\"zh, zh-Hant\"], \"output\":\"path\"}"')
        sys.exit(1)
    g_sourceFile = sys.argv[1]
    dictParams = {}
    try:
        dictParams = eval(sys.argv[2])
        for key, value in dictParams.items():
            g_Params[key.lower()] = value
        sys.exit(int(main() or 0))
    except Exception, e:
        print e
    



# file_source_lan = 'en.strings'

# fh = open(file_source_lan)
# i8nLines = fh.readlines()
# fh.close()

# style0 = xlwt.easyxf('font:height 240, name SimSun')
# wb = xlwt.Workbook(encoding = 'utf-8') 
# ws = wb.add_sheet('Sheet cs')


# index = 0
# noteFlag = False
# for line in i8nLines:
#     if line.strip()[0:2] == '//':
#         # ws.write(index, 0, line)
#         print '注释:' + str(index)
#     elif line.strip()[0:2] == '/*':
#         noteFlag = True
#         print '忽略开始:'
#     elif line.rstrip('\n')[-2:] == '*/':
#         noteFlag = False
#         print '忽略结束'
#     elif noteFlag:
#         print '忽略中:'
#     else:
#         tmpList = line.split('=')
#         if len(tmpList) >= 2:
#             value1 = tmpList[0].strip('"')
#             value2 = tmpList[1].replace('";', '')
#             value2 = value2.lstrip('"')
#             print value1 + ':' + value2
#             ws.write(index, 0, value1, style0)
#             ws.write(index, 1, value2, style0)
#         index += 1

# wb.save('test.xls')
# print i8nLines








