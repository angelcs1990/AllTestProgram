#!/usr/bin/python
#coding:utf-8

#code by cs



def consolePrint(msg):
    	print '\033[31m' + "[提示]" + msg + '\033[0m' 
def actionPrint(msg):
	print '\033[32m' + "[操作]" + msg + '\033[0m' 
def errPrint(msg):
	print '\033[33m' + "[终止运行]" + msg + '\033[0m'


g_debug = 0

Print_Type_Map = {
    "error":errPrint,
    "action":actionPrint,
    "tip":consolePrint
}
def csPrint(msg, printType = 'tip'):
    if g_debug == 1:
        return
    fn = Print_Type_Map.get(printType.lower())
    if fn:
        fn(msg)
    else:
        consolePrint("请输入有效操作：error/action/tip")
      