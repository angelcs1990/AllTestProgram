#! /usr/bin/python
# coding:utf-8

# code by cs

import os
import shutil
import re
import codecs

import datetime
import time

import logging
import sys


# ttttt='eeee@"镂：空设s计 的ss" lsdj @"索,朗多吉：" lsdjf @",老师点击 sd" @"ss",@"s历史剧"'

# #u'@".*?[\u4E00-\u9FA5]+?.*?[\u4E00-\u9FA5]+?"'
# t=re.findall(u'@("[0-9a-zA-Z\\S]*?[^\x00-\xff]+?.*?")', ttttt.decode('utf8'))
# print '===='
# for tmp in t:
#     print tmp.encode('utf8')

# tmpDecode = ttttt.decode('utf8')
# t = re.search(u'@"[\u4E00-\u9FA5]+"', tmpDecode)

# print '====='
# print t.group().encode('utf8')
# tmpT = t.group()
# tmpDecode = tmpDecode.replace(tmpT, u'布拉')
# print tmpDecode.encode('utf8')


# source = 's2f程序员杂志一2d3程序员杂志二2d3程序员杂志三2d3程序员杂志四2d3'
# temp = ttttt.decode('utf8')
# xx=u'@"[\u4e00-\u9fa5]+"'
# pattern = re.compile(xx)
# results = pattern.findall(temp)
# for result in results:
#     print result.encode('utf8')

# exit(0)

# 扣取出字符映射表


countFolders=0
countFiles=0

dst_dir = '.../project/Export/GameGuess_CN2/GameGuess_CN'
map_dirSrc = '.../project/svn/GameGuess_CN2/GameGuess_CN/Supporting Files/Language(国际化)/zh-Hans.lproj/Localizable.strings'
map_dirDef = '.../project/svn/GameGuess_CN2/GameGuess_CN/Supporting Files/Language(国际化)/GGLanguageString.h'
warpperValue = "%s"
g_ignoreFolder = ["WebSocket", "SWebViewController", "Http", "SRouter2", "STableView", "STabView", "SPopView", "CS"]
g_ignoreFiles = ["YYTextView.m", "YYTextUtilities.m", "NSAttributedString+YYText.m", "SR2LocalHandler.m"]

#创建一个logger
class Logger(object):
    def __init__(self, logname, loglevel, logger):
        # 创建一个logger
        self.logger = logging.getLogger(logger)
        self.logger.setLevel(logging.DEBUG)

        # 创建一个handler，用于写入文件
        fh = logging.FileHandler(logname)
        fh.setLevel(logging.DEBUG)

        # 创建一个handler,用于控制台输出
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)

        # 定义输出格式
        formatter = logging.Formatter('%(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)

        self.logger.addHandler(fh)
        self.logger.addHandler(ch)
        
        startOutTitle = '=================' + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + '================='
        self.logger.debug(startOutTitle)

    def getLogger(self):
        return self.logger

logger = Logger(logname='log.txt', loglevel=1, logger="fox").getLogger()
def logPrint(value):
    logger.debug(value)


class TimeDuration(object):
    def __init__(self):
        self.totalCost = 0
    def start(self):
        self.start_time = datetime.datetime.now()
        self.end_time = None
    def getDurationStr(self):
        self.end_time = datetime.datetime.now()
        delta = self.end_time - self.start_time
        # dalta_gmtime = time.gmtime(delta.total_seconds())
        tmpCost = delta.total_seconds()
        self.totalCost += tmpCost
        return str(tmpCost)
    def getTotalCost(self):
        return str(self.totalCost)


class XCodeProjecti8nAutoReplace(object):
    def __init__(self, projectFolder, i8nMapPath):
        self.m_debugModel = True
        self.m_cacheMapi8n = {}
        self.m_countFolder = 0
        self.m_ignoreFolder = g_ignoreFolder
        self.m_ignoreFiles = g_ignoreFiles
        self.m_i8nMapPath = i8nMapPath
        self.m_projectFolder = projectFolder
        self.m_cacheAllFiles = []
        self.m_cacheFile_Array = {}

    def loadi8nMap(self, i8nSrcFile, outMapCache = {}):
        try:
            fHandler = open(i8nSrcFile, 'r')
            tmpLines = fHandler.readlines()
            for line in tmpLines:
                tmp = line.strip(';\n')
                tmpArray = tmp.split('=')
                if len(tmpArray) == 2:
                    outMapCache[tmpArray[1]] = tmpArray[0].replace('"', '')
                else:
                    logPrint('忽略处理:' + line)
        except Exception, e:
            print e
        finally:
            fHandler.close()
    #中文统计
    def listDir(self, path, filter, outFiles):
        for file in os.listdir(path):
            tmpFilePath = os.path.join(path, file)
            if os.path.isdir(tmpFilePath):
                self.m_countFolder += 1
                self.listDir(tmpFilePath, filter, outFiles)
            else:
                if file.endswith(filter):
                    outFiles.append(tmpFilePath)
        return outFiles
    def findKeyForFile(self, filePath, keyValue, cache):
        try:
            f = open(filePath, 'r')
            all_the_lines = f.read()
            t=re.findall(u'@("[0-9a-zA-Z\\S]*?[^\x00-\xff]+?.*?")', all_the_lines.decode('utf8'))
            if t != None and len(t) != 0:
                # os.path.basename(filePath)
                cache[filePath] = t
        except Exception, e:
            logPrint(e)
        finally:
            f.close()

    def outputDebug(self):
        if self.m_debugModel == False:
            return
        for (t, v) in self.m_cacheMapi8n.items():
            logPrint('key:' + t + '\t->value:' + v)
        logPrint('==========================')
        logPrint('查找了' + str(self.m_countFolder) + '个文件夹')
        logPrint('查找了' + str(len(self.m_cacheAllFiles)) + "个文件")
        logPrint('==========================')

        totalCheck = 0
        for (t, v) in self.m_cacheFile_Array.items():
            totalCheck += len(v)
            logPrint('文件' + os.path.split(os.path.dirname(t))[-1] + '/' + os.path.basename(t) + "：" + str(len(v)) + '个')
            for it in v:
                logPrint('\t' + it.encode('utf8'))

        logPrint('===========================')
        logPrint(str(totalCheck) + '个需替换字符检测到')
        logPrint('===========================')

    def analyzeFiles(self):
        for file in self.m_cacheAllFiles:
            self.findKeyForFile(file, '', self.m_cacheFile_Array)
    def readIgnore(self):
        try:
            logPrint('忽略文件输入格式:["TestFolder", "Test2Folder"]')
            ignoreFolder = raw_input('情输入需要忽略的目录(没有直接回车)：')
            ignoreFiles = raw_input('情输入需要忽略的文件(没有直接回车)：')
            
            if len(ignoreFiles) > 0:
                self.m_ignoreFiles = eval(ignoreFiles)
            if len(ignoreFolder) > 0:
                self.m_ignoreFolder = eval(ignoreFolder)

            logPrint('忽略的目录为：' + self.m_ignoreFolder)
            logPrint('忽略的文件为：' + self.m_ignoreFiles)
        except Exception, e:
            print e

    def replaceFiles(self):
        logPrint('************************')
        logPrint('************************')
        logPrint('************************')
        totalCheck = 0
        for (t, v) in self.m_cacheFile_Array.items():
            dirFolder = os.path.split(os.path.dirname(t))[-1]
            dirFileName = os.path.basename(t)
            if dirFolder in self.m_ignoreFolder or dirFileName in self.m_ignoreFiles:
                continue
            tmpList = list(set(v))
            totalCheck += len(tmpList)
            logPrint('处理文件:' + os.path.basename(t) + "：" + str(len(v)) + '个')
            self.dealFile(t, tmpList)
     
        logPrint('===========================')
        logPrint(str(totalCheck) + '个需替换字符检测到')
        logPrint('===========================')

    def dealFile(self, filePath, willArray = []):
        try:
            unChangedList = []
            fHandler = open(filePath, 'r+')
            allContent = fHandler.read()
            changed = False
            for word in willArray:
                #映射表中看有不
                word = word.encode('utf8')
                
                willWord = self.m_cacheMapi8n.get(word)
               
                if willWord != None:
                    logPrint('\t\t@' + word + '替换为' + willWord)
                    changed = True
                    outPut = warpperValue %(willWord)
                    allContent = allContent.replace('@' + word, outPut)
                else:
                    unChangedList.append('@' + word)
            
            logPrint('\t\t未替换：')
            for item in unChangedList:
                logPrint('\t\t@' + item + '没有被替换')

            if changed:
                fHandler.seek(0) 
                fHandler.write(allContent)
        except Exception, e:
            logPrint(e)
        finally:
            fHandler.close()

    def startRun(self, filter):
        logPrint('开始载入语言文件')
        dur = TimeDuration()
        dur.start()
        self.loadi8nMap(self.m_i8nMapPath, self.m_cacheMapi8n)
        logPrint('载入语言文件用时：' + dur.getDurationStr())
        logPrint('开始扫描工程目录')
        self.listDir(self.m_projectFolder, filter, self.m_cacheAllFiles)
        logPrint('扫描工程目录用时：' + dur.getDurationStr())
        logPrint('开始分析工程文件')
        self.analyzeFiles()
        logPrint('分析工程文件用时：' + dur.getDurationStr())

        self.outputDebug()
        self.readIgnore()

        dur.start()
        logPrint('开始文字替换')
        self.replaceFiles()
        logPrint('文字替换用时：' + dur.getDurationStr())
        logPrint('共花费时间：' + dur.getTotalCost())




def main():
    if len(sys.argv) != 6:
        print '出错了' + str(len(sys.argv))
        sys.exit(1)
    
    dst_dir = sys.argv[1]
    map_dirSrc = sys.argv[2]
    warpperValue = sys.argv[3]
    g_ignoreFiles = []
    g_ignoreFolder = []
    if len(sys.argv[4]) > 0:
        g_ignoreFolder = eval(sys.argv[4])
    if len(sys.argv[5]) > 0:
        g_ignoreFiles = eval(sys.argv[5])

    # print dst_dir
    # print map_dirSrc
    # print warpperValue
    # print g_ignoreFolder
    # print g_ignoreFiles

    handler = XCodeProjecti8nAutoReplace(dst_dir, map_dirSrc)
    handler.startRun('.m')
    # outPut = warpperValue %('cs')
    # print outPut

    


if __name__ == '__main__':
    main()
    

