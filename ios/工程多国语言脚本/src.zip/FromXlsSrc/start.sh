#!/bin/bash
#code by cs

function msgTipShow()
{
	echo -e "\033[42;37m[执行] $1\033[0m"
}
function msgErrorShow()
{
	echo -e "\033[31m[出错] $1\033[0m"
}
function msgSucessShow()
{
	echo -e "\033[32m[成功] $1\033[0m"
}
function msgWarningShow()
{
	echo -e "\033[31m[提示] $1\033[0m"
}

msgWarningShow "使用注意："
msgWarningShow "--------------------------------------------------------------------"
msgWarningShow "| 首先请确保i8n_create.py跟i8n_file_replace.py跟本文件在同一文件夹下|"
msgWarningShow "| 其次，请修改i8n_create.py中的left_tag_key跟excel_file_name        |"  
msgWarningShow "| 最后，别忘了修改i8n_file_replace.py中的dest_dir跟src_dir路径      |"
msgWarningShow "--------------------------------------------------------------------"
msgWarningShow "|      code by cs    |"
msgWarningShow "----------------------"
read -n1 -p "按任意键继续。。。"
echo ""

msgTipShow "开始多国语言生成"
python i8n_create.cs
msgTipShow "结束多国语言生成"
msgWarningShow "=========================="
msgTipShow "开始文件替换"
python i8n_file_replace.cs
msgTipShow "结束文件替换"