#!/usr/bin/python
#coding:utf-8

#code by cs

import xlrd
import os
import sys
import re

# data = xlrd.open_workbook('1.xlsx')
# print data.sheets()
# table = data.sheets()[0]
# print type(data)
# print table.row_values(0)
# print table.col_values(0)
# print table.col_values(1)
# print table.col_values(2)
# print table.nrows
# print table.ncols
# print table.cell(0,0).value
# print table.row(0)[0].value
# print table.col(0)[0].value


# 使用规则
# 本程序为ios定制的，其它平台请自行修改
# 下面几个变量为相关目录跟名字，请根据具体项目修改

# 多国语言生成目录（当前文件夹下, 不存在会自行创建)
file_save_folder = 'i8n'
#file_prefix='Localizable'
# 生成语言文件后缀名
file_suffix='.strings'
# 生成key值
left_tag_key = 'key'

# 生成的每个值的注释
value_notes_key = 'zh-Hans'

# excel文件名（请放在同一目录）
excel_file_name='source.xlsx'

# 输出宏定义(1是宏输出 0是static输出 2是模板输出)
open_header_input_type_define = 2
template_example = "static NSString *const {0} = @\"{0}\";\n"

def consolePrint(msg):
	print '\033[31m' + "[提示]" + msg + '\033[0m' 
def actionPrint(msg):
	print '\033[32m' + "[操作]" + msg + '\033[0m' 
def errPrint(msg):
	print '\033[33m' + "[终止运行]" + msg + '\033[0m'  

class excel_process(object):
	"""docstring for excel_process"""
	def __init__(self, filepath):
		super(excel_process, self).__init__()
		self.m_key = ''
		self.m_notesKey = ''
		self.m_headerFileType = 0
		self.m_headerFileTemplate = ''
		self.m_outputFolder = ''
		self.data=None
		self.table=None
		self.open_excel(filepath)
		
	def open_table(self):
		try:
			self.table = self.data.sheets()[0]
		except Exception, e:
			print str(e)
			raise e
	def open_excel(self, excelname):
		try:
			self.data = xlrd.open_workbook(excelname)
			self.open_table()
		except Exception, e:
			print str(e)
			raise e


	def query_key_index(self, match_title):
		#查找match_title所在列
		if self.table.nrows == 0:
			return -1;
		titles = self.table.row_values(0)
		for col in xrange(0,len(titles)):
			if titles[col] == match_title:
				return col
		return -1
	
	def get_path(self):
		def get_cur_path():
			path = sys.path[0]
			if os.path.isdir(path):
				return path
			elif os.path.isfile(path):
				return os.path.dirname(path)
		path = get_cur_path()
		i8n_path = path + '/' + self.m_outputFolder
		if not (os.path.exists(i8n_path)):
			actionPrint('创建了新目录：' + i8n_path.decode('utf-8').encode('gb2312'))
			os.mkdir(i8n_path)
		return i8n_path
	def create_i8n_file(self, dictvalue):
		if len(dictvalue[0]) == 0:
			return -1
		# 获取目录
		i8n_path = self.get_path()

		# 生成新的语言文件
		i8n_file_name = '/' + dictvalue[1][0] + file_suffix
		tmpFilePath = i8n_path + i8n_file_name.decode('utf-8').encode('gb2312')
		f = open(tmpFilePath, 'wb')
		actionPrint('生成新文件：' + i8n_file_name.decode('utf-8').encode('gb2312'))

		def writeToi18nFile(fileHande, idx):
			if self.table.col(0)[idx].value[0:2] == '//':
				value_pair = self.table.col(0)[idx].value + '\n'
			elif self.table.col(0)[idx].value[0] == '#':
				if dictvalue[1][idx] != '' and dictvalue[1][idx][0] == '#':
					value_pair = 'CFBundleDisplayName=' + '\"' + dictvalue[1][idx][1:-1] + '\";\n'
				else:
					value_pair = 'CFBundleDisplayName=' + '\"' + self.table.col(0)[idx].value[1:-1] + '\";\n'
			else:
				value_pair='\"' + dictvalue[0][idx] + '\"' + '=' + '\"' + dictvalue[1][idx] + '\"' + ';\n'
			strss = value_pair.encode('utf-8')
			fileHande.write(strss)
		lastIdx = len(dictvalue[0])-1
		for idx in xrange(1, lastIdx):
			writeToi18nFile(f, idx)

		
		writeToi18nFile(f, lastIdx)
		f.close()

	def get_notes(self, arrayValues):
		# 注释所在的列
		keyColIndex = self.query_key_index(self.m_notesKey)
		if keyColIndex == -1:
			errPrint("没有匹配到注释值")
			return None
		#映射的左值
		keys = self.table.col_values(keyColIndex);

		if len(keys) != len(arrayValues):
			errPrint("注释值长度不匹配")
			return None

		return keys;
	def create_i18n_header(self,dictvalue):
		if len(dictvalue[0]) == 0:
			return -1
		# 获取目录
		i8n_path = self.get_path()
		i8n_file_name='i18n_header.h'
		tmpFileName = '/' + i8n_file_name
		tmpFilePath = i8n_path + tmpFileName.decode('utf-8').encode('gb2312')
		# tmpFilePath = tmpFilePath.decode('gb2312', 'ignore').encode('utf-8', 'ignore')
		f = open(tmpFilePath, 'wb')
		actionPrint('生成新文件：' + i8n_file_name.decode('utf-8').encode('gb2312'))
		f.write("#ifndef i18n_header_h\n")
		f.write("#define i18n_header_h\n")

		# 注释获取
		notes = self.get_notes(dictvalue[0]);

		def writeToi18nFile_static(fileHande, idx):
			value_pair=''
			if self.table.col(0)[idx].value[0:2] == '//':
				value_pair = self.table.col(0)[idx].value + '\n'
			elif self.table.col(0)[idx].value[0] == '#':
				if dictvalue[1][idx] != '' and dictvalue[1][idx][0] == '#':
					value_pair = 'CFBundleDisplayName=' + '\"' + dictvalue[1][idx][1:-1] + '\";\n'
				else:
					value_pair = 'CFBundleDisplayName=' + '\"' + self.table.col(0)[idx].value[1:-1] + '\";\n'
			else:
				if notes != None:
					value_pair = '/**' + notes[idx] + '*/\n'
				value_pair += 'static NSString *const ' + dictvalue[0][idx] + '=' + '@\"' + dictvalue[0][idx] + '\"' + ';\n'
			strss = value_pair.encode('utf-8')
			fileHande.write(strss)
		def writeToi18nFile_template(fileHande, idx):
			value_pair=''
			if self.table.col(0)[idx].value[0:2] == '//':
				value_pair = self.table.col(0)[idx].value + '\n'
			elif self.table.col(0)[idx].value[0] == '#':
				if dictvalue[1][idx] != '' and dictvalue[1][idx][0] == '#':
					value_pair = 'CFBundleDisplayName=' + '\"' + dictvalue[1][idx][1:-1] + '\";\n'
				else:
					value_pair = 'CFBundleDisplayName=' + '\"' + self.table.col(0)[idx].value[1:-1] + '\";\n'
			else:
				if notes != None:
					value_pair = '/**' + notes[idx] + '*/\n'
				# 模板解析
				templateStr = self.m_headerFileTemplate.replace('{0}', dictvalue[0][idx]).replace('{1}', dictvalue[1][idx])
				value_pair += templateStr
			strss = value_pair.encode('utf-8')
			fileHande.write(strss)
		def writeToi18nFile_define(fileHande, idx):
			value_pair=''
			if self.table.col(0)[idx].value[0:2] == '//':
				value_pair = self.table.col(0)[idx].value + '\n'
			elif self.table.col(0)[idx].value[0] == '#':
				if dictvalue[1][idx] != '' and dictvalue[1][idx][0] == '#':
					value_pair = 'CFBundleDisplayName=' + '\"' + dictvalue[1][idx][1:-1] + '\";\n'
				else:
					value_pair = 'CFBundleDisplayName=' + '\"' + self.table.col(0)[idx].value[1:-1] + '\";\n'
			else:
				if notes != None:
					value_pair = '/**' + notes[idx] + '*/\n'
				value_pair += '#define ' + dictvalue[0][idx] + ' ' + 'LOCALIZATION(@\"' + dictvalue[0][idx] + '\")' + ';\n'
			strss = value_pair.encode('utf-8')
			fileHande.write(strss)

		lastIdx = len(dictvalue[0])-1
		if self.m_headerFileType == 0:
			for idx in xrange(1, lastIdx):
				writeToi18nFile_static(f, idx)
			writeToi18nFile_static(f, lastIdx)
		elif self.m_headerFileType == 1:
			for idx in xrange(1, lastIdx):
				writeToi18nFile_define(f, idx)
			writeToi18nFile_define(f, lastIdx)
		elif self.m_headerFileType == 2:
			for idx in xrange(1, lastIdx):
				writeToi18nFile_template(f, idx)
			writeToi18nFile_template(f, lastIdx)

		
		f.write("#endif\n")
		f.close()

	def create_i8n_values(self):
		#关键字key所在的列
		keyColIndex = self.query_key_index(self.m_key)
		if keyColIndex == -1:
			errPrint("没有找到匹配左值")
			return -1
		#总共列数
		cols = self.table.ncols
		
		#映射的左值
		keys = self.table.col_values(keyColIndex);

		keyValues = []
		bKeyValuesEmpty = True
		for col in xrange(0,cols):
			tmpValue =[[],[]]
			values = self.table.col_values(col)

			if len(keys) != len(values):
				errPrint("映射数据不对称")
				return -1
			for row_idx in xrange(0,len(values)):
				# tmpValue[0].append(keys[row_idx].strip().replace(' ', '_'))
				if bKeyValuesEmpty == True:
					keyValues.append(keys[row_idx].strip().replace(' ', '_'))
				tmpValue[1].append(values[row_idx])
			

			tmpValue[0] = keyValues
			bKeyValuesEmpty = False

			# 生成数据文件
			self.create_i8n_file(tmpValue)
			# 生成header文件
			if col == keyColIndex:
				self.create_i18n_header(tmpValue)

def main():
	key = g_Params['key']
	notesKey = g_Params['notesKey']
	sourceFile = g_Params['sourceFile']
	headerFileType = int(g_Params['headerFileType'])
	headerFileTemplate = g_Params['headerFileTemplate']
	outputFolder = g_Params['outputFolder']

	tmpDict = {0:'默认static', 1:"默认define", 2:"自定义"}
	if headerFileType < 0 or headerFileType > 2:
		headerFileType = 0
	consolePrint("主键:" + key)
	consolePrint("注释键:" + notesKey)
	consolePrint("源文件:" + sourceFile)
	consolePrint("生成头文件类型:" + tmpDict[headerFileType])
	consolePrint("头文件模板:" + headerFileTemplate.replace('\n', ''))
	consolePrint("输出目录:" + outputFolder)

	consolePrint("成功后，请用i8n_file_replace.py脚本进行下一步操作")
	ep = excel_process(sourceFile)
	ep.m_key = key
	ep.m_notesKey = notesKey
	ep.m_headerFileType = headerFileType
	ep.m_headerFileTemplate = headerFileTemplate
	ep.m_outputFolder = outputFolder
	ep.create_i8n_values()
g_Params = {
	"key":left_tag_key,
	"notesKey":value_notes_key,
	"sourceFile":excel_file_name,
	"headerFileType":open_header_input_type_define,
	"headerFileTemplate":template_example,
	"outputFolder":file_save_folder
}

if __name__ == '__main__':
	import sys
	if len(sys.argv) > 1 and len(sys.argv) != 2:
		csPrint('例子: i8n_create_GGame.cs "{\"key\":\"key\", \"notesKey\":\"zh-Hans\", \"sourceFile\":\"source.xlsx\", \"headerFileType\":\"2\", \"headerFileTemplate\":\'static NSString *const {0} = @\"{0}\";\n\', \"outputFolder\":\"i8n\"}"')
		sys.exit(1)
	dictParams = {}
	try:
		if len(sys.argv) == 2:
			dictParams = eval(sys.argv[1])
			for key, value in dictParams.items():
				if value.strip() != '':
					g_Params[key] = value
		sys.exit(int(main() or 0))
	except Exception, e:
		print e

