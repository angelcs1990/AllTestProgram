#!/usr/bin/python
#coding:utf-8

#code by cs

import os
import sys
import shutil
# ios定制程序 
# 以下全局变脸请根据实际情况修改

# 源目录跟目标目录
# dest_dir = ios多国语言目录
# src_dir = i8n_create.py生成的目录
dest_dir = '.../Desktop/i8n/Language(国际化)'
src_dir = '.../Desktop/i8n/i8n'
#生成同一名称
des_name = 'Localizable.strings'
# print root_dir
# print isinstance(root_dir, unicode)
# ust = root_dir.encode('utf-8')
def consolePrint(msg):
	print '\033[31m' + "[提示]" + msg + '\033[0m' 
def actionPrint(msg):
	print '\033[32m' + "[操作]" + msg + '\033[0m' 
def listDir(path):
	filelist=[]
	for i in os.listdir(path):
		if i[0] == '.':
			consolePrint('忽略：' + i)
			continue
		filelist.append(path + '/' + i)
	return filelist

def checkPathValid(path):
	if os.path.exists(path):
		return True
	else:
		return False


def cpFile(srcPaths, des_paths):
	tmpDstName = g_Params['destName']
	for srcPath in srcPaths:
		src_filename = os.path.basename(srcPath)
		src_filename = src_filename.split('.')[0]
		for desPath in des_paths:
			des_filename = os.path.basename(desPath)
			des_filename = des_filename.split('.')[0]
			# print srcPath
			# print desPath + '/' + des_name
			# print src_filename + '=' + des_filename
			if src_filename == des_filename:
				outputTip = "已复制：源路径("+os.path.basename(srcPath)+")到目标路径("+os.path.basename(desPath)+")"
				actionPrint(outputTip)
				shutil.copyfile(srcPath, desPath + '/' + tmpDstName)
				des_paths.remove(desPath)
				break


def main():
	tmpDstDir = g_Params['destDir']
	tmpSrcDir = g_Params['srcDir']


	if False == checkPathValid(tmpDstDir):
		consolePrint(tmpDstDir + "不存在")
		sys.exit(-3)
	if False == checkPathValid(tmpSrcDir):
		consolePrint(tmpSrcDir + "不存在")
		sys.exit(-3)
	folders = listDir(tmpDstDir)
	src_folders = listDir(tmpSrcDir)

	if len(folders) == 0:
		consolePrint("没找到多国语言文件夹")
		sys.exit(-1)
	if len(src_folders) == 0:
		consolePrint("没找到i8n_create.py生成的多国语言文件")
		sys.exit(-2)
	cpFile(src_folders, folders)

g_Params = {
	"destDir":dest_dir,
	"srcDir":src_dir,
	"destName":des_name
}

if __name__ == '__main__':
	import sys
	if len(sys.argv) > 1 and len(sys.argv) != 2:
		csPrint('例子: i8n_create_GGame.cs "{\"destDir\":\"key\", \"srcDir\":\"zh-Hans\", \"destName\":\"source.xlsx\"}"')
		sys.exit(1)
	dictParams = {}
	try:
		if len(sys.argv) == 2:
			dictParams = eval(sys.argv[1])
			for key, value in dictParams.items():
				if value.strip() != '':
					g_Params[key] = value
		sys.exit(int(main() or 0))
	except Exception, e:
		print e
