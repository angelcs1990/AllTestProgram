#!/usr/bin/python
#coding:utf-8

#code by cs

import xlrd
import os
import sys
import re

# data = xlrd.open_workbook('1.xlsx')
# print data.sheets()
# table = data.sheets()[0]
# print type(data)
# print table.row_values(0)
# print table.col_values(0)
# print table.col_values(1)
# print table.col_values(2)
# print table.nrows
# print table.ncols
# print table.cell(0,0).value
# print table.row(0)[0].value
# print table.col(0)[0].value


# 使用规则
# 本程序为ios定制的，其它平台请自行修改
# 下面几个变量为相关目录跟名字，请根据具体项目修改

# 多国语言生成目录（当前文件夹下, 不存在会自行创建)
file_save_folder = 'i8n'
#file_prefix='Localizable'
# 生成语言文件后缀名
file_suffix='.strings'
# 生成key值
left_tag_key = 'en'

# excel文件名（请放在同一目录）
excel_file_name='source.xlsx'


def consolePrint(msg):
	print '\033[31m' + "[提示]" + msg + '\033[0m' 
def actionPrint(msg):
	print '\033[32m' + "[操作]" + msg + '\033[0m' 

class excel_process(object):
	"""docstring for excel_process"""
	def __init__(self):
		super(excel_process, self).__init__()
		self.data=None
		self.table=None
		
	def open_table(self):
		try:
			self.table = self.data.sheets()[0]
		except Exception, e:
			print str(e)
			raise e
	def open_excel(self, excelname):
		try:
			self.data = xlrd.open_workbook(excelname)
			self.open_table()
		except Exception, e:
			print str(e)
			raise e

	def query_left_tags(self, match_title):
		#查找match_title所在列
		if self.table.nrows == 0:
			return ''
		col_index = 0
		tags = []
		titles = self.table.row_values(0)
		for title in titles:
			if title == match_title:
				tags = self.table.col_values(col_index)
				return tags
			col_index += 1
		return ''
	def get_cur_path(self):
		path = sys.path[0]
		if os.path.isdir(path):
			return path
		elif os.path.isfile(path):
			return os.path.dirname(path)
	def create_i8n_file(self, dictvalue):
		path = self.get_cur_path()
		i8n_path = path + '/' + file_save_folder
		if not (os.path.exists(i8n_path)):
			actionPrint('创建了新目录：' + i8n_path.decode('utf-8').encode('gb2312'))
			os.mkdir(i8n_path)
		# print i8n_path
		if len(dictvalue[0]) == 0:
			return -1
		i8n_file_name=''
		f=None
		for idx in xrange(0, len(dictvalue[0])):
			strss = ''
			if idx == 0:
				# i8n_file_name = file_prefix  + file_suffix+'('+ dictvalue[1][idx] + ')'
				i8n_file_name = dictvalue[1][idx] + file_suffix
				tmpFilePath = i8n_path + '/' + i8n_file_name
				f = open(tmpFilePath, 'wb')
				actionPrint('生成新文件：' + i8n_file_name.decode('utf-8').encode('gb2312'))
			elif idx == len(dictvalue[0])-1:
				if self.table.col(0)[idx].value[0:2] == '//':
					value_pair = self.table.col(0)[idx].value + '\n'
				elif self.table.col(0)[idx].value[0] == '#':
					if dictvalue[1][idx] != '' and dictvalue[1][idx][0] == '#':
						value_pair = 'CFBundleDisplayName=' + '\"' + dictvalue[1][idx][1:-1] + '\";\n'
					else:
						value_pair = 'CFBundleDisplayName=' + '\"' + self.table.col(0)[idx].value[1:-1] + '\";\n'
				else:
					value_pair='\"' + dictvalue[0][idx] + '\"' + '=' + '\"' + dictvalue[1][idx] + '\"' + ';\n'
				strss = value_pair.encode('utf-8')
				f.write(strss)
				f.close()
			else:
				if self.table.col(0)[idx].value[0:2] == '//':
					value_pair = self.table.col(0)[idx].value + '\n'
				elif self.table.col(0)[idx].value[0] == '#':
					if dictvalue[1][idx] != '' and dictvalue[1][idx][0] == '#':
						value_pair = 'CFBundleDisplayName=' + '\"' + dictvalue[1][idx][1:-1] + '\";\n'
					else:
						value_pair = 'CFBundleDisplayName=' + '\"' + self.table.col(0)[idx].value[1:-1] + '\";\n'
				else:
					value_pair='\"' + dictvalue[0][idx] + '\"' + '=' + '\"' + dictvalue[1][idx] + '\"' + ';\n'
				strss = value_pair.encode('utf-8')
				f.write(strss)

		
	def create_i8n_values(self):
		tags = self.query_left_tags(left_tag_key)
		cols = self.table.ncols
		
		for idx in xrange(0,cols):
			tmpValue =[[],[]]
			values = self.table.col_values(idx)
			if len(tags) != len(values):
				print 'left not equal right value'
				return -1
			for row_idx in xrange(0,len(values)):
				tmpValue[0].append(tags[row_idx])
				tmpValue[1].append(values[row_idx])
				# tmpDict[tags[row_idx]] = values[row_idx]
			# print tmpValue
			self.create_i8n_file(tmpValue)


consolePrint("如果操作成功，会在当前目录下生成i8n文件夹，生成的文件都会在里面")
consolePrint("成功后，请用i8n_file_replace.py脚本进行下一步操作")
ep = excel_process()
ep.open_excel(excel_file_name)
ep.create_i8n_values()
sys.exit(0)
# if __name__ == "__main__":